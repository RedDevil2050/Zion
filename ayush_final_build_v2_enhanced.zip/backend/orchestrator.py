import concurrent.futures
import importlib
import glob
import os

AGENT_DIR = "/mnt/data/ayush_final_build_real/backend/agents"

def run(symbol: str) -> dict:
    results = []

    # Find all agent scripts
    agent_paths = glob.glob(os.path.join(AGENT_DIR, "**/*.py"), recursive=True)

    def execute_agent(path):
        try:
            spec = importlib.util.spec_from_file_location("agent", path)
            agent = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(agent)
            return agent.run(symbol)
        except Exception as e:
            return {"agent": path.split("/")[-1], "verdict": "ERROR", "score": 0, "insight": str(e)}

    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(execute_agent, path) for path in agent_paths]
        for future in concurrent.futures.as_completed(futures):
            results.append(future.result())

    # Aggregate final verdict
    final_score = sum(r.get("score", 0) for r in results if r["verdict"] != "ERROR") / max(1, len(results))
    if final_score >= 75:
        final_verdict = "BUY"
    elif final_score >= 60:
        final_verdict = "HOLD"
    else:
        final_verdict = "SELL"

    return {
        "symbol": symbol.upper(),
        "final_verdict": final_verdict,
        "final_score": round(final_score, 2),
        "agents_used": len(results),
        "agent_results": results
    }
