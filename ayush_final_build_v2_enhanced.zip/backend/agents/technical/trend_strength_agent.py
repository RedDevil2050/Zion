def run(symbol: str) -> dict:
    adx = 28
    score = 85 if adx >= 25 else 60 if adx >= 20 else 45
    verdict = "STRONG TREND" if score >= 80 else "MODERATE" if score >= 60 else "WEAK"
    return {
        "agent": "technical/trend_strength_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"ADX Value: {adx}"
    }
