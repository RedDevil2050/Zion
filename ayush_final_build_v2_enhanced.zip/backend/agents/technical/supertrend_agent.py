def run(symbol: str) -> dict:
    price = 102
    supertrend = 99
    score = 85 if price > supertrend else 55
    verdict = "UPTREND" if price > supertrend else "DOWNTREND"
    return {
        "agent": "technical/supertrend_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"Price: {price}, Supertrend: {supertrend}"
    }
