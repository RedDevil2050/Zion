def run(symbol: str) -> dict:
    rsi = 58
    score = 85 if 45 <= rsi <= 65 else 60 if 35 <= rsi <= 70 else 40
    verdict = "NEUTRAL" if 45 <= rsi <= 65 else "OVERSOLD" if rsi < 30 else "OVERBOUGHT"
    return {
        "agent": "technical/rsi_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"RSI: {rsi}"
    }
