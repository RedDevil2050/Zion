def run(symbol: str) -> dict:
    adx = 34
    score = 90 if adx >= 30 else 70 if adx >= 20 else 50
    verdict = "STRONG TREND" if adx >= 30 else "MODERATE" if adx >= 20 else "WEAK"
    return {
        "agent": "technical/adx_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"ADX: {adx}"
    }
