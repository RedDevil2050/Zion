def run(symbol: str) -> dict:
    avg_volume = 1_000_000
    today_volume = 2_500_000
    score = 90 if today_volume > 2 * avg_volume else 60
    verdict = "UNUSUAL VOLUME" if score > 75 else "NORMAL"
    return {
        "agent": "technical/volume_spike_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"Today's Volume: {today_volume}, Avg: {avg_volume}"
    }
