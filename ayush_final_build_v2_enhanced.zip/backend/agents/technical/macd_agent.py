def run(symbol: str) -> dict:
    macd_histogram = 1.2
    score = 85 if macd_histogram > 0 else 55
    verdict = "BULLISH" if macd_histogram > 0 else "BEARISH"
    return {
        "agent": "technical/macd_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"MACD Histogram: {macd_histogram}"
    }
