def run(symbol: str) -> dict:
    k = 80
    d = 75
    score = 85 if k > d and k > 70 else 60
    verdict = "OVERBOUGHT" if k > 80 else "NEUTRAL" if 20 < k < 80 else "OVERSOLD"
    return {
        "agent": "technical/stochastic_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"Stochastic %K: {k}, %D: {d}"
    }
