def run(symbol: str) -> dict:
    price = 105
    upper_band = 110
    lower_band = 90
    score = 80 if lower_band < price < upper_band else 55
    verdict = "WITHIN BANDS" if lower_band < price < upper_band else "OUTSIDE RANGE"
    return {
        "agent": "technical/bollinger_band_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"Price: {price}, Bands: ({lower_band}, {upper_band})"
    }
