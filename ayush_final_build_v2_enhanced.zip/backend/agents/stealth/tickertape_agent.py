import requests
from bs4 import BeautifulSoup
import time
import random

def run(symbol: str) -> dict:
    url = f"https://www.tickertape.in/stocks/{symbol.lower()}/"
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
    ]
    headers = {
        "User-Agent": random.choice(user_agents)
    }

    try:
        time.sleep(random.uniform(1.5, 3.0))
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")

        def safe_extract(label):
            try:
                tag = soup.find("span", string=label)
                if tag:
                    return tag.find_next("span").text.strip()
            except Exception:
                return None

        pe_ratio = safe_extract("P/E")
        eps = safe_extract("EPS")
        pb_ratio = safe_extract("P/B")
        debt_equity = safe_extract("Debt/Equity")

        return {
            "agent": "stealth/tickertape_agent",
            "symbol": symbol,
            "source": url,
            "pe_ratio": pe_ratio or "N/A",
            "eps": eps or "N/A",
            "pb_ratio": pb_ratio or "N/A",
            "debt_equity": debt_equity or "N/A"
        }

    except Exception as e:
        return {
            "agent": "stealth/tickertape_agent",
            "symbol": symbol,
            "error": str(e)
        }
