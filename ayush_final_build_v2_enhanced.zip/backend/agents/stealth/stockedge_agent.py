import requests
from bs4 import BeautifulSoup
import time
import random

def run(symbol: str) -> dict:
    url = f"https://www.stockedge.com/stock/{symbol.lower()}/"
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
    ]
    headers = {
        "User-Agent": random.choice(user_agents)
    }

    try:
        time.sleep(random.uniform(1.5, 3.0))
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")

        def safe_find(label):
            try:
                tag = soup.find("span", text=label)
                if tag:
                    return tag.find_next("span").text.strip()
            except Exception:
                return None

        pe_ratio = safe_find("PE")
        eps = safe_find("EPS")
        roe = safe_find("ROE")
        market_cap = safe_find("Market Cap")

        return {
            "agent": "stealth/stockedge_agent",
            "symbol": symbol,
            "source": url,
            "pe_ratio": pe_ratio or "N/A",
            "eps": eps or "N/A",
            "roe": roe or "N/A",
            "market_cap": market_cap or "N/A"
        }

    except Exception as e:
        return {
            "agent": "stealth/stockedge_agent",
            "symbol": symbol,
            "error": str(e)
        }
