import logging
import time

def log_execution(func):
    def wrapper(symbol):
        start = time.time()
        try:
            result = func(symbol)
            duration = round(time.time() - start, 2)
            logging.info(f"[{func.__name__}] Success | Symbol: {symbol} | Time: {duration}s")
            return result
        except Exception as e:
            logging.error(f"[{func.__name__}] Failure | Symbol: {symbol} | Error: {str(e)}")
            return {"agent": func.__name__, "verdict": "ERROR", "score": 0, "insight": str(e)}
    return wrapper


@log_execution
def run(symbol: str) -> dict:
    revenue_growth = 0.18  # 18%
    earnings_growth = 0.22  # 22%
    avg_growth = round((revenue_growth + earnings_growth) / 2, 2)
    score = 90 if avg_growth >= 0.20 else 70 if avg_growth >= 0.10 else 50
    verdict = "HIGH GROWTH" if score > 85 else "MODERATE" if score >= 70 else "LOW"
    return {
        "agent": "valuation/growth_valuation_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"Revenue Growth: {revenue_growth*100}%, EPS Growth: {earnings_growth*100}%, Avg: {avg_growth*100}%"
    }
