def run(symbol: str) -> dict:
    try:
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
        news_text = "Company earnings exceeded expectations and outlook remains positive."
        analyzer = SentimentIntensityAnalyzer()
        sentiment_score = analyzer.polarity_scores(news_text)['compound']
    except ModuleNotFoundError:
        # Fallback score if vaderSentiment is not available
        news_text = "Company earnings exceeded expectations and outlook remains positive."
        sentiment_score = 0.7

    score = int((sentiment_score + 1) * 50)
    verdict = "POSITIVE" if score >= 65 else "NEUTRAL" if score >= 45 else "NEGATIVE"
    return {
        "agent": "sentiment/news_sentiment_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"Sentiment Score (fallback ok): {sentiment_score} from news: {news_text[:40]}..."
    }
