def run(symbol: str) -> dict:
    # Placeholder: Whisper + BERT pipeline
    transcript_text = "We had a strong quarter with solid growth in all segments."
    tone_score = 0.68  # Simulated LLM output
    score = int(tone_score * 100)
    verdict = "CONFIDENT" if score >= 70 else "STABLE" if score >= 50 else "CAUTIOUS"
    return {
        "agent": "sentiment/earnings_tone_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"Simulated Whisper + BERT tone score: {tone_score}"
    }
