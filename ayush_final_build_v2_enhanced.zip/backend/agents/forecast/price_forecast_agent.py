def run(symbol: str) -> dict:
    current_price = 1000
    forecast_growth_rate = 0.06  # 6% annual growth
    future_price = round(current_price * (1 + forecast_growth_rate), 2)
    score = 85 if forecast_growth_rate >= 0.05 else 60
    verdict = "UPWARD TREND" if score >= 80 else "STABLE"
    return {
        "agent": "forecast/price_forecast_agent",
        "score": score,
        "verdict": verdict,
        "insight": f"Projected Price: ₹{future_price} (+{forecast_growth_rate*100}%)"
    }
